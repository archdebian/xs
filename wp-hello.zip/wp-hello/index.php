<?php
/**
 * Plugin Name: Hello Joy
 * Description: This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis
 * Armstrong: Hello, Dolly. When activated you will randomly see a lyric from <cite>Hello, Dolly</cite> in the upper right of your admin screen on every page.
 * Version: 1.7.2
 * Author: Matt Mullenweg
 * Author URI: http://ma.tt/
 */

?>
